package com.example.kinethall

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.kinethall.fragments.HomeFragment
import com.example.kinethall.fragments.ProfileFragment
import com.example.kinethall.fragments.SearchFragment
import com.example.kinethall.fragments.adapters.ViewPagerAdapter
import kotlinx.android.synthetic.main.activity_2.*

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)

        supportActionBar?.hide()


        setUpTabs()
    }

    private fun setUpTabs()
    {
        val adapter = ViewPagerAdapter(supportFragmentManager)
        adapter.addFragment(HomeFragment(), "Home")
        adapter.addFragment(SearchFragment(), "Search")
        adapter.addFragment(ProfileFragment(), "Profile")
        viewPager.adapter = adapter
        tabs.setupWithViewPager(viewPager)

        tabs.getTabAt(0)!!.setIcon(R.drawable.ic_baseline_home_24)
        tabs.getTabAt(1)!!.setIcon(R.drawable.ic_baseline_search_24)
        tabs.getTabAt(2)!!.setIcon(R.drawable.ic_baseline_account_circle_24)
    }
}